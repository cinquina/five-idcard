fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'five developments!'
description 'feel free to use and modify, i coded this shit in like 10 mins or sum LOL'

ui_page 'web/index.html'

files {
    'web/index.html',
    'web/style.css',
    'web/script.js',
    'web/error.png',
}

client_script 'client.lua'
dependency '/assetpacks'