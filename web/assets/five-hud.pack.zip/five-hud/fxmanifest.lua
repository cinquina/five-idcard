fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'five developments!'

ui_page 'web/index.html'

shared_script 'config.lua'
client_script 'client.lua'

files {
    'web/*.html',
    'web/*.css',
    'web/*.js',
    'web/icons/*.png',
    'web/audio/*.mp3',
}

escrow_ignore {
    'config.lua',
    'stream/*'
}
dependency '/assetpacks'