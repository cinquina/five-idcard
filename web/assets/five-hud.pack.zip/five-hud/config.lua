Config = {}

Config.Framework = "ESX" -- ESX / QBCore
Config.Voice = 'pma-voice' -- pma-voice / saltychat
Config.VoiceProgress = {
    [1] = 33,
    [2] = 66,
    [3] = 100
}

Config.NotifyFunction = function(text) 
    SetNotificationTextEntry("STRING")
    AddTextComponentString(text)
    DrawNotification(true, false)
end

Config.MinimapZoom = 1100 -- Advanced only, do not touch please
Config.MinimapJustInVehicle = true

Config.EnableSpeedometer = true -- Enable / disable our default speedometer

Config.Stress = true -- enable / disable stress

Config.UpdateTimeout = 700 -- every X seconds the hud will update
Config.UpdateCarTimeout = 500 -- every X seconds the car hud will update
Config.Unit = "kmh" -- kmh / mph, not case sensitive

Config.FuelScript = 'ox_fuel' -- ox_fuel, LegacyFuel, standalone

Config.Seatbelt = true -- enable or disable seatbelt
Config.SeatbeltBind = "B" -- seatbelt bind
Config.SeatbeltRagdollSpeed = 100

Config.Lang = {
    ["seatbelt_on"] = "Seatbelt on",
    ["seatbelt_off"] = "Seatbelt off"
}